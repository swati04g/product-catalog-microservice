package main.java.com.product.data.enums;

public enum StatusCode implements java.io.Serializable {

	/** The SUCCESS. */
	SUCCESS,
	
	/** The ERROR. */
	ERROR,

	/** The FAILED. */
	FAILED,

	

}
