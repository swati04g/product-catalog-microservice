insert into product (name,product_type) values
('Pasta', 'Food'),
('Car', 'Automobile');